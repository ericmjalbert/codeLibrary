/*
 * -------------------------------------------------------------
 *  defect.c
 *  A program that checks the defect between wavespeed values 
 *    using the back-transformed solution and solving the 
 *    wavespeed from it.
 * -------------------------------------------------------------
 *  Author              :   Eric Jalbert
 *  Date Created        :   August 15, 2013
 *  Date Last Modified  :   August 15, 2013
 * -------------------------------------------------------------
 */
 
#include<math.h> 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>


/* Problem Parameters */
#define ALPHA 4
#define BETA  4
#define GAMMA 4
#define MU    6
#define DELTA 1.0e-8
#define KAPPA 0.95

#define STEP  1.0e-3
#define LOOPCOUNT 7

/*-----------------------------------
 * Functions used by solver functions
 *-----------------------------------
 */
 
/* D(y1), the density function */
double Diffusion(double y1)
{
    return DELTA * pow(y1, ALPHA) * pow(1-y1, -BETA);
}

/* f(y1), the growth rate function */
double Growth(double y1)
{
    return MU * y1 * (1 - pow((y1/KAPPA), GAMMA));
}


/*--------------
 * Main Function
 *--------------
 */

int main()
{
  FILE * file = NULL;
  char filename[100];
  char line[100];
  char * token = NULL;
  char ** endptr = NULL;
  double uVal[8000];
  double uDeriv[8000];
  double u2ndDeriv[8000];
  double ** wavespeed = malloc(sizeof **wavespeed * 8);
  int loop, count = 0, i;
  
  for(loop = 0; loop <= 4; loop++)
  {
    count = 0;
  
    sprintf(filename, "backTrans%d.dat", loop);
    file = fopen(filename, "r");
    
    /* Extract uVals from file */
    while(fgets(line, sizeof(line), file) != NULL)
    {
      token = strtok(line, " ");
      token = strtok(NULL, "\n");
      
      uVal[count] = strtod(token, endptr);
      count++;
    }
        
    
    
    wavespeed[loop] = malloc(sizeof *wavespeed[loop] * count);
    
    /* Calculate uDeriv Values */
    for(i = 0; i < count; i++)
    {
      if(i+3 < count)
        uDeriv[i] = (-11.0/6.0*uVal[i] + 3*uVal[i+1] - 1.5*uVal[i+2] + 1.0/3.0*uVal[i+3])/STEP;
      else
        uDeriv[i] = (11.0/6.0*uVal[i] - 3*uVal[i-1] + 1.5*uVal[i-2] - 1.0/3.0*uVal[i-3])/STEP;



      /* multiply by D(U) here cause it's easier... */
      uDeriv[i] *= Diffusion(uVal[i]);
      printf("uDeriv[%d] = %0.10f \n", i, uDeriv[i]);

    }
    
        printf("\n-----------\n");
    
    
    /* Calculate u2ndDeriv Values */
    for(i = 0; i < count; i++)
    {
      if(i+3 < count)
        u2ndDeriv[i] = (-11.0/6.0*uDeriv[i] + 3*uDeriv[i+1] - 1.5*uDeriv[i+2] + 1.0/3.0*uDeriv[i+3])/STEP;
      else
        u2ndDeriv[i] = (11.0/6.0*uDeriv[i] - 3*uDeriv[i+1] + 1.5*uDeriv[i+2] - 1.0/3.0*uDeriv[i+3])/STEP;
        
      /* Add f(U) here cause its easier... */
      u2ndDeriv[i] += Growth(uVal[i]);

    }
    
    
        printf("\n-----------\n");
    
    /* Calculate c for this one gridpoint; i.e. divid by uVal... */
    for(i = 0; i < count; i++)
    {
      if(uVal[i] != 0)
        wavespeed[loop][i] = -u2ndDeriv[i]/uVal[i];
      else
        wavespeed[loop][i] = 0;
      
      printf("wavespeed[%d][%d] = %f\n", loop, i, wavespeed[loop][i]);
    }
    
    fclose(file);
  }
  
  
  for(i = 0; i <= LOOPCOUNT; i++)
    free(wavespeed[i]);
  free(wavespeed);
  
  
  return 1;

}





