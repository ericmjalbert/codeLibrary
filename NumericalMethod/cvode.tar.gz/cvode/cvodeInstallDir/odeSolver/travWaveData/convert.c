#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define KAPPA 0.95
#define ALPHA 4
#define BETA  4
#define GAMMA 4
#define MU    6
#define DELTA 1.0e-8

float D(float y1)
{
    return DELTA * pow(y1, ALPHA) / pow(1-y1, BETA) ;

}

int main()
{

    char line[2000];
    char * num;
    double zetaVal[40000];
    double uVal[40000];
    double zVal[40000];
    int i = 0, j,loop;
    char fileName[100];
    FILE * file;
    
for(loop = 5; loop < 8; loop++)
{
    i = 0;
    /* Read in file */
    sprintf(fileName, "traj%d.dat",loop);
    file = fopen(fileName, "r");
    while (fgets(line, sizeof(line), file) != NULL)
    {
        num = strtok(line, " ");
        zetaVal[i] = atof(num);
        
        num = strtok(NULL, " ");
        uVal[i] = atof(num);
        
        i++;
        
    } 
    fclose(file);
    /*
    zVal[i] = 2 * (zetaVal[i-1] + zetaVal[i]) * (D(uVal[i-1]) * D(uVal[i]))/(D(uVal[i-1]) + D(uVal[i]));
    for(j = 0; j < i; j++)
    {
      zVal[i-j-1] = zVal[i-j] + 2 * (zetaVal[i-1-j] + zetaVal[i-j]) * (D(uVal[i-1-j]) * D(uVal[i-j]))/(D(uVal[i-1-j]) + D(uVal[i-j]));
    }
    */
    zVal[0] = 0;
    for(j = 1; j < i; j++)
    {
      zVal[j] = zVal[j-1] + 2 * (zetaVal[j] + zetaVal[j-1]) * D(uVal[j]) * D(uVal[j-1])/(D(uVal[j]) + D(uVal[j-1]));
    }

    
    /* Write to file */
    sprintf(fileName, "backTrans%d.dat",loop);
    file = fopen(fileName, "w");
    for(j = 0; j < i; j++)
    {
        fprintf(file, "%.16f %.16f\n", -zVal[j], uVal[j]);
    }
    fclose(file);

}

    return 1;

}




